package com.example.OrderService.service;

import com.example.OrderService.model.OrderRequestModel;

public interface OrderService {
	int placeOrder(OrderRequestModel orm);

}
